﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_232410101054_utspbo.App.Models
{
    public class M_DashboardAdmin
    {
        [Key]
        public string judul { get; set; }
        [Required]
        public string deskripsi { get; set; }
        [Required]
        public string deadline { get; set; }
        [Required]
    }
}
