﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using B_232410101054_utspbo.App.Core;
using B_232410101054_utspbo.App.Model;

namespace B_232410101054_utspbo.App.Context
{
    internal class C_DashboardAdmin : DatabaseWrapper
    {
        private static string table = "admin";

        public static long loginAdmin(string judul, string deskripsi, string deadline)
        {
            try
            {
                string query = $"SELECT COUNT(*) FROM {table} " +
                $"WHERE judul = @judul AND deskripsi = @deskripsi AND deadline = @deadline"
                NpgsqlParameter[] parameters = {
                    new NpgsqlParameter("judul", NpgsqlDbType.Varchar) { Value = judul }, new NpgsqlParameter("deskripsi", NpgsqlDbType.Varchar) { Value = deskripsi }, new NpgsqlParameter("deadline", NpgsqlDbType.Varchar) { Value = deadline }
                };

                long result = commandExecutor(query, parameters);
                return result > 0 ? 1 : 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return 0;
            }
        }
    }
}