﻿namespace B_232410101054_utspbo.Views
{
    partial class Dashboard_Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Judul = new Label();
            Deskripsi = new Label();
            Deadline = new Label();
            textBoxJudul = new TextBox();
            textBoxDesc = new TextBox();
            btnTambah = new Button();
            btnBatal = new Button();
            dateTimePickerDL = new DateTimePicker();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(264, 51);
            label1.Name = "label1";
            label1.Size = new Size(269, 31);
            label1.TabIndex = 0;
            label1.Text = "Menambah Tugas Baru";
            label1.Click += label1_Click;
            // 
            // Judul
            // 
            Judul.AutoSize = true;
            Judul.Font = new Font("Segoe UI", 10F);
            Judul.Location = new Point(91, 139);
            Judul.Name = "Judul";
            Judul.Size = new Size(59, 23);
            Judul.TabIndex = 1;
            Judul.Text = "Judul :";
            // 
            // Deskripsi
            // 
            Deskripsi.AutoSize = true;
            Deskripsi.Font = new Font("Segoe UI", 10F);
            Deskripsi.Location = new Point(91, 215);
            Deskripsi.Name = "Deskripsi";
            Deskripsi.Size = new Size(86, 23);
            Deskripsi.TabIndex = 2;
            Deskripsi.Text = "Deskripsi :";
            // 
            // Deadline
            // 
            Deadline.AutoSize = true;
            Deadline.Font = new Font("Segoe UI", 10F);
            Deadline.Location = new Point(91, 291);
            Deadline.Name = "Deadline";
            Deadline.Size = new Size(86, 23);
            Deadline.TabIndex = 3;
            Deadline.Text = "Deadline :";
            // 
            // textBoxJudul
            // 
            textBoxJudul.Location = new Point(201, 135);
            textBoxJudul.Name = "textBoxJudul";
            textBoxJudul.Size = new Size(185, 27);
            textBoxJudul.TabIndex = 4;
            // 
            // textBoxDesc
            // 
            textBoxDesc.Location = new Point(201, 211);
            textBoxDesc.Name = "textBoxDesc";
            textBoxDesc.Size = new Size(185, 27);
            textBoxDesc.TabIndex = 5;
            // 
            // btnTambah
            // 
            btnTambah.BackColor = Color.SeaGreen;
            btnTambah.ImageAlign = ContentAlignment.MiddleRight;
            btnTambah.Location = new Point(546, 380);
            btnTambah.Name = "btnTambah";
            btnTambah.Size = new Size(113, 39);
            btnTambah.TabIndex = 7;
            btnTambah.Text = "Tambah";
            btnTambah.UseVisualStyleBackColor = false;
            btnTambah.Click += btnTambah_Click;
            // 
            // btnBatal
            // 
            btnBatal.BackColor = Color.Red;
            btnBatal.ImageAlign = ContentAlignment.MiddleRight;
            btnBatal.Location = new Point(684, 380);
            btnBatal.Name = "btnBatal";
            btnBatal.Size = new Size(113, 39);
            btnBatal.TabIndex = 8;
            btnBatal.Text = "Batal";
            btnBatal.UseVisualStyleBackColor = false;
            // 
            // dateTimePickerDL
            // 
            dateTimePickerDL.Location = new Point(201, 287);
            dateTimePickerDL.Name = "dateTimePickerDL";
            dateTimePickerDL.Size = new Size(250, 27);
            dateTimePickerDL.TabIndex = 9;
            // 
            // Dashboard_Admin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(859, 472);
            Controls.Add(dateTimePickerDL);
            Controls.Add(btnBatal);
            Controls.Add(btnTambah);
            Controls.Add(textBoxDesc);
            Controls.Add(textBoxJudul);
            Controls.Add(Deadline);
            Controls.Add(Deskripsi);
            Controls.Add(Judul);
            Controls.Add(label1);
            Name = "Dashboard_Admin";
            Text = "Dashboard_Admin";
            Load += Dashboard_Admin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label Judul;
        private Label Deskripsi;
        private Label Deadline;
        private TextBox textBoxJudul;
        private TextBox textBoxDesc;
        private Button btnTambah;
        private Button btnBatal;
        private DateTimePicker dateTimePickerDL;
    }
}