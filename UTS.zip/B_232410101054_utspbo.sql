CREATE TABLE admin(
	id serial primary key,
	username varchar(255) not null,
	password varchar(255) not null
);

select * from admin

CREATE TABLE dashboard_adm(
judul varchar(255),
deskripsi varchar(255),
deadline varchar(100)
);